# Тест #1

Минимальное Android-приложение на Kotlin: тёмный экран, счётчик нажатий, сброс и автоматическое сохранение результата.

## Как получить APK на компьютере

1. Установите Android Studio с официального сайта: https://developer.android.com/studio
2. Распакуйте архив `Test1_Android_Project.zip`.
3. В Android Studio выберите **Open** и укажите распакованную папку `test1_android`.
4. Дождитесь Gradle Sync и установки Android SDK (если Android Studio предложит).
5. Выберите **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. APK появится в `app/build/outputs/apk/debug/app-debug.apk`.
7. Передайте APK на телефон и откройте его. При запросе Android разрешите установку из этого источника.

## Что умеет приложение

- Увеличивает счётчик по нажатию.
- Сбрасывает счётчик.
- Сохраняет значение после закрытия приложения.

Минимальная версия Android: 6.0 (API 23).
