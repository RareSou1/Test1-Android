package com.example.test1

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 18, 32)
    private val panel = Color.rgb(25, 36, 58)
    private val accent = Color.rgb(55, 126, 230)
    private val prefs by lazy { getSharedPreferences("test1", MODE_PRIVATE) }
    private var count = 0
    private lateinit var number: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        count = prefs.getInt("count", 0)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(bg)
        }

        val title = TextView(this).apply {
            text = "ТЕСТ #1"
            textSize = 15f
            letterSpacing = 0.18f
            setTextColor(Color.rgb(145, 174, 215))
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap())

        val greeting = TextView(this).apply {
            text = "Первый запуск"
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 8)
        }
        root.addView(greeting, matchWrap())

        val subtitle = TextView(this).apply {
            text = "Ваше первое Android-приложение"
            textSize = 15f
            setTextColor(Color.rgb(170, 184, 207))
            gravity = Gravity.CENTER
        }
        root.addView(subtitle, matchWrap())

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(22, 28, 22, 28)
            setBackgroundColor(panel)
        }
        val cardParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = 42 }
        root.addView(card, cardParams)

        val label = TextView(this).apply {
            text = "СЧЁТЧИК НАЖАТИЙ"
            textSize = 13f
            letterSpacing = 0.08f
            setTextColor(Color.rgb(165, 186, 218))
            gravity = Gravity.CENTER
        }
        card.addView(label, matchWrap())

        number = TextView(this).apply {
            textSize = 64f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 18)
        }
        card.addView(number, matchWrap())
        updateNumber()

        val add = Button(this).apply {
            text = "+  НАЖАТЬ"
            textSize = 16f
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(accent)
            setOnClickListener {
                count++
                prefs.edit().putInt("count", count).apply()
                updateNumber()
            }
        }
        card.addView(add, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 58
        ))

        val reset = Button(this).apply {
            text = "Сбросить счётчик"
            textSize = 14f
            isAllCaps = false
            setTextColor(Color.rgb(195, 208, 228))
            setBackgroundColor(Color.rgb(42, 55, 78))
            setOnClickListener {
                count = 0
                prefs.edit().putInt("count", count).apply()
                updateNumber()
            }
        }
        val resetParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 52
        ).apply { topMargin = 12 }
        card.addView(reset, resetParams)

        val footer = TextView(this).apply {
            text = "Значение сохраняется автоматически"
            textSize = 12f
            setTextColor(Color.rgb(125, 145, 175))
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }
        root.addView(footer, matchWrap())

        setContentView(root)
    }

    private fun updateNumber() {
        number.text = count.toString()
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    )
}
